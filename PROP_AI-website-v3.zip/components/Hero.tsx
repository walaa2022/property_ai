"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useLanguage } from '@/context/LanguageContext';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldCheck, Star } from 'lucide-react';
import SearchBar from './SearchBar';

export default function Hero() {
  const { lang, t } = useLanguage();

  const slides = [
    "https://images.unsplash.com/photo-1613977257363-707ba9348227?q=80&w=2070&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1613490493576-7fde63acd811?q=80&w=2071&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?q=80&w=2070&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=2070&auto=format&fit=crop",
  ];
  const [current, setCurrent] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => setCurrent((p) => (p + 1) % slides.length), 6500);
    return () => clearInterval(timer);
  }, [slides.length]);

  return (
    <section
      aria-labelledby="hero-title"
      style={{
        position: 'relative',
        overflow: 'hidden',
        background: 'linear-gradient(180deg, #FFFBF5 0%, #F7F0E4 100%)',
        paddingTop: 'clamp(120px, 16vh, 180px)',
        paddingBottom: '60px',
      }}
    >
      {/* Soft ambient shape */}
      <div aria-hidden style={{
        position: 'absolute',
        top: '-10%',
        insetInlineEnd: '-10%',
        width: '55vw',
        height: '55vw',
        background: 'radial-gradient(circle, rgba(216,104,74,0.08) 0%, transparent 65%)',
        filter: 'blur(40px)',
        pointerEvents: 'none',
      }} />

      <div className="container" style={{ position: 'relative', zIndex: 1 }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'minmax(0, 1.15fr) minmax(0, 1fr)',
          gap: 'clamp(24px, 5vw, 64px)',
          alignItems: 'center',
        }} className="hero-grid">
          <div>
            <div style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 8,
              background: 'var(--accent-soft)',
              color: 'var(--accent)',
              padding: '6px 14px',
              borderRadius: 'var(--radius-pill)',
              fontSize: 12,
              fontWeight: 700,
              marginBottom: '1.25rem',
            }}>
              <Star size={14} fill="currentColor" strokeWidth={0} aria-hidden />
              <span>{t.hero.marketIntel}</span>
            </div>

            <h1 id="hero-title" style={{ marginBottom: '1rem', maxWidth: 720 }}>
              <span style={{ display: 'block' }}>{t.hero.headline}</span>
              <span style={{
                display: 'block',
                fontStyle: 'italic',
                color: 'var(--accent)',
              }}>{t.hero.subHeadline}</span>
            </h1>

            <p style={{
              fontSize: '1.05rem',
              marginBottom: '1.75rem',
              maxWidth: 560,
            }}>
              {t.hero.desc}
            </p>

            <div style={{ marginBottom: '1.5rem' }}>
              <SearchBar />
            </div>

            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
              <Link href="/business" className="btn-secondary" aria-label={t.hero.ctaSecondary}>
                {t.hero.ctaSecondary}
              </Link>
              <div style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: 10,
                fontSize: 13,
                color: 'var(--ink-muted)',
                fontWeight: 500,
              }}>
                <ShieldCheck size={18} color="var(--sage)" aria-hidden />
                <span>{t.hero.verified}</span>
              </div>
            </div>
          </div>

          {/* Property photo stack */}
          <div style={{
            position: 'relative',
            height: 'clamp(340px, 52vh, 520px)',
            borderRadius: 'var(--radius-lg)',
            overflow: 'hidden',
            boxShadow: 'var(--shadow-lift)',
          }}>
            <AnimatePresence mode="wait">
              <motion.img
                key={current}
                src={slides[current]}
                alt={lang === 'EN'
                  ? `Featured property ${current + 1} of ${slides.length}`
                  : `عقار مختار ${current + 1} من ${slides.length}`}
                initial={{ opacity: 0, scale: 1.06 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
                style={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover',
                  position: 'absolute',
                  inset: 0,
                }}
              />
            </AnimatePresence>

            {/* Floating trust card */}
            <div style={{
              position: 'absolute',
              insetInlineStart: 20,
              bottom: 20,
              background: 'rgba(255, 251, 245, 0.96)',
              backdropFilter: 'blur(10px)',
              borderRadius: 'var(--radius)',
              padding: '14px 18px',
              boxShadow: 'var(--shadow-card)',
              display: 'flex',
              alignItems: 'center',
              gap: 12,
              maxWidth: 260,
            }}>
              <div style={{
                width: 40, height: 40, borderRadius: '50%',
                background: 'var(--sage-soft)', color: 'var(--sage)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontWeight: 700,
              }}>
                4.9
              </div>
              <div>
                <div style={{ fontWeight: 700, fontSize: 13, color: 'var(--ink)' }}>
                  {lang === 'EN' ? 'Rated by 2,300+ clients' : 'تقييم من 2300+ عميل'}
                </div>
                <div style={{ fontSize: 11, color: 'var(--ink-muted)', display: 'flex', gap: 2, marginTop: 2 }}>
                  {[0,1,2,3,4].map(i => (
                    <Star key={i} size={11} fill="var(--accent)" strokeWidth={0} aria-hidden />
                  ))}
                </div>
              </div>
            </div>

            {/* Corner label */}
            <div aria-hidden style={{
              position: 'absolute',
              top: 20,
              insetInlineEnd: 20,
              background: 'rgba(255, 251, 245, 0.96)',
              color: 'var(--ink)',
              padding: '6px 14px',
              fontSize: 11,
              fontWeight: 700,
              borderRadius: 'var(--radius-pill)',
              letterSpacing: 0.3,
            }}>
              {lang === 'EN' ? 'Featured home' : 'منزل مميز'}
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @media (max-width: 900px) {
          .hero-grid {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </section>
  );
}
