"use client";
import React from "react";
import Link from "next/link";
import { Home } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";

export default function SiteFooter() {
  const { t } = useLanguage();

  const columns = [
    {
      heading: t.footer.forBuyers,
      links: [
        { label: t.nav.sale, href: "/sale" },
        { label: t.featured.allCollections, href: "/sale" },
        { label: t.nav.contact, href: "/contact" },
      ],
    },
    {
      heading: t.footer.forRenters,
      links: [
        { label: t.nav.rental, href: "/rental" },
        { label: t.consumerTypes?.renting?.title ?? "Rentals", href: "/rental" },
        { label: t.nav.contact, href: "/contact" },
      ],
    },
    {
      heading: t.footer.forInvestors,
      links: [
        { label: t.consumerTypes?.investing?.title ?? "Investing", href: "/sale" },
        { label: t.nav.brokerage, href: "/brokerage" },
      ],
    },
    {
      heading: t.footer.forBusiness,
      links: [
        { label: t.nav.business, href: "/business" },
        { label: t.business.cta, href: "/contact" },
        { label: t.nav.login, href: "/login" },
      ],
    },
  ];

  return (
    <footer
      style={{
        padding: "80px 0 48px",
        borderTop: "1px solid var(--border-soft)",
        background: "var(--surface-warm)",
        color: "var(--ink)",
      }}
      aria-label={t.footer.tagline}
    >
      <div className="container" style={{ maxWidth: 1200, margin: "0 auto" }}>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1.2fr repeat(auto-fit, minmax(160px, 1fr))",
            gap: "2.5rem",
            marginBottom: "3rem",
          }}
        >
          <div style={{ maxWidth: 320 }}>
            <Link
              href="/"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 10,
                marginBottom: "1rem",
                textDecoration: "none",
              }}
              aria-label="PROP_AI home"
            >
              <div
                style={{
                  background: "var(--accent)",
                  width: 34,
                  height: 34,
                  borderRadius: 10,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                }}
              >
                <Home size={17} color="#fff" strokeWidth={2.5} aria-hidden />
              </div>
              <span
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 600,
                  fontSize: "1.35rem",
                  letterSpacing: "-0.5px",
                  color: "var(--ink)",
                }}
              >
                Prop<span style={{ color: "var(--accent)", fontStyle: "italic" }}>ai</span>
              </span>
            </Link>
            <p style={{ fontSize: "0.95rem", color: "var(--ink-muted)", margin: 0, lineHeight: 1.55 }}>
              {t.footer.tagline}
            </p>
          </div>

          {columns.map((col) => (
            <div key={col.heading}>
              <div
                style={{
                  fontSize: "11px",
                  fontWeight: 700,
                  letterSpacing: "1.5px",
                  textTransform: "uppercase",
                  color: "var(--accent)",
                  marginBottom: "1rem",
                }}
              >
                {col.heading}
              </div>
              <ul
                style={{
                  listStyle: "none",
                  padding: 0,
                  margin: 0,
                  display: "flex",
                  flexDirection: "column",
                  gap: "0.65rem",
                }}
              >
                {col.links.map((l) => (
                  <li key={`${col.heading}-${l.label}-${l.href}`}>
                    <Link
                      href={l.href}
                      style={{
                        color: "var(--ink)",
                        fontSize: "0.92rem",
                        fontWeight: 500,
                        textDecoration: "none",
                      }}
                    >
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div
          style={{
            borderTop: "1px solid var(--border-soft)",
            paddingTop: "1.5rem",
            display: "flex",
            flexWrap: "wrap",
            gap: "1rem",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <p style={{ fontSize: "0.85rem", color: "var(--ink-muted)", margin: 0 }}>
            {t.footer.rights}
          </p>
          <div style={{ display: "flex", gap: "1.25rem", flexWrap: "wrap" }}>
            <Link
              href="/about"
              style={{ fontSize: "0.85rem", color: "var(--ink-muted)", textDecoration: "none" }}
            >
              {t.nav.about}
            </Link>
            <Link
              href="/contact"
              style={{ fontSize: "0.85rem", color: "var(--ink-muted)", textDecoration: "none" }}
            >
              {t.nav.contact}
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
