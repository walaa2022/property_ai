"use client";
import React, { useState } from 'react';
import Link from 'next/link';
import { Globe, Menu, X, Home } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';

export default function Navbar() {
  const { lang, setLang, t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);

  const toggleLang = () => setLang(lang === 'EN' ? 'AR' : 'EN');

  const navLinks = [
    { href: '/', label: t.nav.home },
    { href: '/sale', label: t.nav.sale },
    { href: '/rental', label: t.nav.rental },
    { href: '/brokerage', label: t.nav.brokerage },
    { href: '/business', label: t.nav.business },
    { href: '/contact', label: t.nav.contact },
    { href: '/about', label: t.nav.about },
  ];

  return (
    <>
      <nav
        aria-label="Main"
        style={{
          position: 'fixed',
          top: 0,
          insetInlineStart: 0,
          width: '100%',
          zIndex: 1000,
          padding: '14px 0',
          background: 'rgba(255, 251, 245, 0.92)',
          backdropFilter: 'blur(16px)',
          borderBottom: '1px solid var(--border-soft)',
        }}
      >
        <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16 }}>
          <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: 10 }} aria-label="PROP_AI home">
            <div style={{
              background: 'var(--accent)',
              width: 34,
              height: 34,
              borderRadius: 10,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
            }}>
              <Home size={17} color="#fff" strokeWidth={2.5} aria-hidden />
            </div>
            <span style={{
              fontFamily: 'var(--font-heading)',
              fontWeight: 600,
              fontSize: '1.3rem',
              letterSpacing: '-0.5px',
              color: 'var(--ink)',
              whiteSpace: 'nowrap',
            }}>
              Prop<span style={{ color: 'var(--accent)', fontStyle: 'italic' }}>ai</span>
            </span>
          </Link>

          <div className="hidden-md" style={{ display: 'flex', gap: 28, alignItems: 'center' }}>
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                style={{ fontSize: 14, fontWeight: 500, color: 'var(--ink)' }}
              >
                {link.label}
              </Link>
            ))}
          </div>

          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <button
              onClick={toggleLang}
              aria-label={t.nav.switchLanguage}
              style={{
                background: 'transparent',
                border: '1px solid var(--border)',
                color: 'var(--ink)',
                padding: '8px 14px',
                borderRadius: 'var(--radius-pill)',
                fontSize: 13,
                fontWeight: 600,
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                cursor: 'pointer',
                transition: 'var(--transition)',
              }}
            >
              <Globe size={14} aria-hidden /> {lang === 'EN' ? 'AR' : 'EN'}
            </button>

            <div className="hidden-sm" style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
              <Link
                href="/login"
                style={{ fontSize: 14, fontWeight: 500, color: 'var(--ink)' }}
              >
                {t.nav.login}
              </Link>
              <Link
                href="/signup"
                className="btn-primary"
                style={{ padding: '10px 22px', minHeight: 40, fontSize: 14 }}
              >
                {t.nav.getStarted}
              </Link>
            </div>

            <button
              className="show-sm"
              onClick={() => setIsOpen(!isOpen)}
              aria-label={t.nav.toggleMenu}
              aria-expanded={isOpen}
              aria-controls="mobile-menu"
              style={{
                background: 'transparent',
                border: '1px solid var(--border)',
                borderRadius: 'var(--radius-pill)',
                width: 40,
                height: 40,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--ink)',
                cursor: 'pointer',
                zIndex: 3000,
              }}
            >
              {isOpen ? <X size={20} aria-hidden /> : <Menu size={20} aria-hidden />}
            </button>
          </div>
        </div>
      </nav>

      <div id="mobile-menu" className={`mobile-menu-overlay ${isOpen ? 'active' : ''}`} aria-hidden={!isOpen}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="mobile-nav-link"
              onClick={() => setIsOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          <div style={{ height: 1, background: 'var(--border-soft)', margin: '1rem 0' }} />
          <Link href="/login" onClick={() => setIsOpen(false)} style={{ fontSize: '1.25rem', color: 'var(--ink)', fontWeight: 500 }}>
            {t.nav.login}
          </Link>
          <Link href="/signup" onClick={() => setIsOpen(false)} className="btn-primary" style={{ width: '100%' }}>
            {t.nav.getStarted}
          </Link>
        </div>
      </div>
    </>
  );
}
