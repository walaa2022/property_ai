"use client";
import React from "react";
import { motion } from "framer-motion";
import { useLanguage } from "@/context/LanguageContext";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default function EntryPoints() {
  const { lang, t } = useLanguage();

  const entries = [
    {
      title: t.consumerTypes.buying.title,
      id: "buying",
      href: "/sale",
      description: t.consumerTypes.buying.desc,
      img: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?q=80&w=800&auto=format&fit=crop",
    },
    {
      title: t.consumerTypes.renting.title,
      id: "renting",
      href: "/rental",
      description: t.consumerTypes.renting.desc,
      img: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?q=80&w=800&auto=format&fit=crop",
    },
    {
      title: t.consumerTypes.investing.title,
      id: "investing",
      href: "/brokerage",
      description: t.consumerTypes.investing.desc,
      img: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=800&auto=format&fit=crop",
    },
    {
      title: t.consumerTypes.selling.title,
      id: "selling",
      href: "/contact",
      description: t.consumerTypes.selling.desc,
      img: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=800&auto=format&fit=crop",
    },
  ];

  const arrow = (
    <ArrowRight size={16} aria-hidden style={lang === "AR" ? { transform: "scaleX(-1)" } : undefined} />
  );

  return (
    <section className="container" aria-labelledby="entry-heading">
      <div style={{ textAlign: "center", marginBottom: "3rem", maxWidth: 640, marginInline: "auto" }}>
        <h2 id="entry-heading" style={{ marginBottom: "0.75rem" }}>
          {t.entryPoints.dreamHeader}{" "}
          <span style={{ fontStyle: "italic", color: "var(--accent)" }}>
            {t.entryPoints.dreamSub}
          </span>
        </h2>
        <p style={{ fontSize: "1.05rem" }}>{t.entryPoints.desc}</p>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
          gap: "1.25rem",
        }}
      >
        {entries.map((item) => (
          <Link
            key={item.id}
            href={item.href}
            style={{ textDecoration: "none", color: "inherit", display: "block" }}
            aria-label={`${item.title}`}
          >
            <motion.div
              whileHover={{ y: -6 }}
              style={{
                background: "var(--surface)",
                borderRadius: "var(--radius-lg)",
                overflow: "hidden",
                boxShadow: "var(--shadow-soft)",
                transition: "var(--transition)",
                height: "100%",
                display: "flex",
                flexDirection: "column",
                border: "1px solid var(--border-soft)",
              }}
            >
              <div style={{ position: "relative", aspectRatio: "4 / 3", overflow: "hidden" }}>
                <img
                  src={item.img}
                  alt=""
                  aria-hidden
                  style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
                />
              </div>
              <div style={{ padding: "1.5rem", display: "flex", flexDirection: "column", gap: "0.6rem", flex: 1 }}>
                <h3 style={{ fontSize: "1.15rem", lineHeight: 1.3 }}>{item.title}</h3>
                <p style={{ fontSize: "0.92rem", margin: 0 }}>{item.description}</p>
                <div
                  style={{
                    marginTop: "auto",
                    paddingTop: "0.5rem",
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 6,
                    color: "var(--accent)",
                    fontSize: "0.9rem",
                    fontWeight: 600,
                  }}
                >
                  {lang === "EN" ? "Explore" : "استكشف"} {arrow}
                </div>
              </div>
            </motion.div>
          </Link>
        ))}
      </div>
    </section>
  );
}
