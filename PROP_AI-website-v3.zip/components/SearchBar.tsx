"use client";
import React from "react";
import { useLanguage } from "@/context/LanguageContext";
import { Search, MapPin, Home as HomeIcon, Wallet } from "lucide-react";

export default function SearchBar() {
  const { lang } = useLanguage();

  const labels = lang === "AR"
    ? { where: "أين", whereP: "مدينة أو حي", what: "النوع", whatP: "شقة، فيلا...", budget: "الميزانية", budgetP: "أي ميزانية", go: "ابحث" }
    : { where: "Where", whereP: "City or area", what: "Type", whatP: "Any property", budget: "Budget", budgetP: "Any budget", go: "Search" };

  return (
    <form
      role="search"
      className="search-bar"
      aria-label={labels.go}
      onSubmit={(e) => e.preventDefault()}
    >
      <label className="field">
        <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <MapPin size={12} aria-hidden /> {labels.where}
        </span>
        <input type="text" placeholder={labels.whereP} aria-label={labels.where} />
      </label>
      <label className="field">
        <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <HomeIcon size={12} aria-hidden /> {labels.what}
        </span>
        <input type="text" placeholder={labels.whatP} aria-label={labels.what} />
      </label>
      <label className="field">
        <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <Wallet size={12} aria-hidden /> {labels.budget}
        </span>
        <input type="text" placeholder={labels.budgetP} aria-label={labels.budget} />
      </label>
      <button type="submit" className="search-btn" aria-label={labels.go}>
        <Search size={16} aria-hidden />
        <span className="hidden-sm">{labels.go}</span>
      </button>
    </form>
  );
}
