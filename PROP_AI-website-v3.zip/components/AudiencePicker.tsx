"use client";
import React from "react";
import Link from "next/link";
import { useLanguage } from "@/context/LanguageContext";
import { motion } from "framer-motion";
import { Home, Briefcase, ArrowRight } from "lucide-react";

export default function AudiencePicker() {
  const { lang, t } = useLanguage();
  const Arrow = (
    <ArrowRight
      size={16}
      aria-hidden
      style={lang === "AR" ? { transform: "scaleX(-1)" } : undefined}
    />
  );

  const cards = [
    {
      key: "consumer",
      icon: <Home size={24} aria-hidden />,
      href: "/sale",
      title: t.audience.consumer.title,
      sub: t.audience.consumer.sub,
      desc: t.audience.consumer.desc,
      cta: t.audience.consumer.cta,
      tint: "var(--accent-soft)",
      tintInk: "var(--accent)",
    },
    {
      key: "business",
      icon: <Briefcase size={24} aria-hidden />,
      href: "/business",
      title: t.audience.business.title,
      sub: t.audience.business.sub,
      desc: t.audience.business.desc,
      cta: t.audience.business.cta,
      tint: "var(--sage-soft)",
      tintInk: "var(--sage)",
    },
  ];

  return (
    <section aria-labelledby="audience-heading" className="container">
      <div style={{ textAlign: "center", marginBottom: "2.5rem", maxWidth: 620, marginInline: "auto" }}>
        <h2 id="audience-heading" style={{ marginBottom: "0.75rem" }}>
          {t.audience.heading}
        </h2>
        <p style={{ fontSize: "1.05rem" }}>{t.audience.desc}</p>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
          gap: "1.5rem",
        }}
      >
        {cards.map((c) => (
          <Link
            key={c.key}
            href={c.href}
            aria-label={`${c.title} — ${c.cta}`}
            style={{ textDecoration: "none", color: "inherit", display: "block" }}
          >
            <motion.div
              whileHover={{ y: -6 }}
              whileFocus={{ y: -6 }}
              style={{
                padding: "2rem",
                height: "100%",
                display: "flex",
                flexDirection: "column",
                gap: "1rem",
                background: "var(--surface)",
                border: "1px solid var(--border-soft)",
                borderRadius: "var(--radius-lg)",
                boxShadow: "var(--shadow-soft)",
                transition: "var(--transition)",
              }}
            >
              <div
                style={{
                  width: 56,
                  height: 56,
                  borderRadius: "var(--radius)",
                  background: c.tint,
                  color: c.tintInk,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                {c.icon}
              </div>
              <h3 style={{ fontSize: "1.4rem", lineHeight: 1.25 }}>{c.title}</h3>
              <div
                style={{
                  fontSize: "0.8rem",
                  fontWeight: 600,
                  color: c.tintInk,
                  textTransform: "uppercase",
                  letterSpacing: "1.2px",
                }}
              >
                {c.sub}
              </div>
              <p style={{ fontSize: "0.98rem", margin: 0 }}>{c.desc}</p>
              <div
                style={{
                  marginTop: "auto",
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 8,
                  color: c.tintInk,
                  fontSize: "0.95rem",
                  fontWeight: 600,
                }}
              >
                {c.cta} {Arrow}
              </div>
            </motion.div>
          </Link>
        ))}
      </div>
    </section>
  );
}
