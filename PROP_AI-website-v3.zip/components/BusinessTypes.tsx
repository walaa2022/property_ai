"use client";
import React from "react";
import Link from "next/link";
import { useLanguage } from "@/context/LanguageContext";
import {
  Building2,
  Landmark,
  UserCheck,
  Wrench,
  Repeat,
  KeyRound,
  Banknote,
  TrendingUp,
} from "lucide-react";

type Variant = "section" | "page";

export default function BusinessTypes({ variant = "section" }: { variant?: Variant }) {
  const { t } = useLanguage();

  const types = [
    { key: "broker", icon: Building2 },
    { key: "developer", icon: Landmark },
    { key: "agent", icon: UserCheck },
    { key: "propertyManager", icon: Wrench },
    { key: "resale", icon: Repeat },
    { key: "rental", icon: KeyRound },
    { key: "mortgage", icon: Banknote },
    { key: "investor", icon: TrendingUp },
  ] as const;

  return (
    <section
      aria-labelledby="business-heading"
      style={{
        background: "var(--surface-warm)",
        paddingTop: 80,
        paddingBottom: 80,
      }}
    >
      <div className="container">
        <div style={{ textAlign: "center", marginBottom: "3rem", maxWidth: 720, marginInline: "auto" }}>
          <div
            style={{
              display: "inline-block",
              fontSize: 12,
              fontWeight: 700,
              letterSpacing: "1.5px",
              textTransform: "uppercase",
              color: "var(--accent)",
              marginBottom: "1rem",
              background: "var(--accent-soft)",
              padding: "6px 14px",
              borderRadius: "var(--radius-pill)",
            }}
          >
            {t.business.sub}
          </div>
          <h2 id="business-heading" style={{ marginBottom: "0.75rem" }}>
            {t.business.heading}
          </h2>
          <p style={{ fontSize: "1.05rem" }}>{t.business.desc}</p>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
            gap: "1.25rem",
          }}
        >
          {types.map(({ key, icon: Icon }) => {
            const item = t.business.types[key];
            return (
              <div
                key={key}
                style={{
                  background: "var(--surface)",
                  borderRadius: "var(--radius-lg)",
                  padding: "1.75rem 1.5rem",
                  display: "flex",
                  flexDirection: "column",
                  gap: "0.75rem",
                  boxShadow: "var(--shadow-soft)",
                  border: "1px solid var(--border-soft)",
                  transition: "var(--transition)",
                }}
              >
                <div
                  style={{
                    width: 48,
                    height: 48,
                    borderRadius: "var(--radius)",
                    background: "var(--accent-soft)",
                    color: "var(--accent)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Icon size={22} aria-hidden />
                </div>
                <h3 style={{ fontSize: "1.1rem", lineHeight: 1.3 }}>{item.title}</h3>
                <p style={{ fontSize: "0.92rem", margin: 0 }}>{item.desc}</p>
              </div>
            );
          })}
        </div>

        {variant === "section" && (
          <div style={{ textAlign: "center", marginTop: "2.5rem" }}>
            <Link href="/business" className="btn-primary">
              {t.business.learnMore}
            </Link>
          </div>
        )}
      </div>
    </section>
  );
}
